// Content script for monitoring ChatGPT UI elements
class ChatGPTMonitor {
  constructor() {
    this.currentStatus = null; // Start with null status until we can properly detect it
    this.observer = null;
    this.lastStatusChange = Date.now();
    this.statusChangeDelay = 1000; // 1 second delay to avoid rapid status changes
    this.baseTitle = null; // Store the clean base title
    this.chimePlayer = new ChimePlayer('content');
    this.settings = new Settings();
    this.init();
  }

  init() {
    // Wait for page to be fully loaded
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () =>
        this.startMonitoring()
      );
    } else {
      this.startMonitoring();
    }
  }

  startMonitoring() {

    // Wait for chat interface to be ready before initial status check
    this.waitForChatInterface(() => {
      this.checkStatus();
    });

    // Set up mutation observer to watch for DOM changes
    this.setupMutationObserver();

    // Also check periodically as a fallback
    setInterval(() => this.checkStatus(), 1000);
  }

  waitForChatInterface(callback) {
    // Check if we're on a chat page first
    if (!this.isChatPage()) {
      // Still set a base title for non-chat pages
      try {
        this.baseTitle = this.getCleanTitle() || "ChatGPT";
      } catch (error) {
        this.baseTitle = "ChatGPT";
      }
      callback();
      return;
    }

    const checkInterface = () => {
      // Look for the specific ProseMirror textarea that indicates chat interface is fully loaded
      const proseMirrorTextarea = document.querySelector(
        '#prompt-textarea.ProseMirror[contenteditable="true"]'
      );

      if (proseMirrorTextarea) {
        // Store the base title when interface is ready
        try {
          this.baseTitle = this.getCleanTitle() || "ChatGPT";
        } catch (error) {
          this.baseTitle = "ChatGPT";
        }
        // Wait additional 250ms to ensure everything is fully initialized
        setTimeout(() => {
          callback();
        }, 250);
      } else {
        setTimeout(checkInterface, 500);
      }
    };

    checkInterface();
  }

  isChatPage() {
    const url = window.location.href;
    // Monitor both conversation pages and the main chat interface
    return (
      url.includes("/c/") ||
      url === "https://chat.openai.com/" ||
      url === "https://chatgpt.com/" ||
      url.startsWith("https://chat.openai.com/?") ||
      url.startsWith("https://chatgpt.com/?")
    );
  }

  setupMutationObserver() {
    this.observer = new MutationObserver((mutations) => {
      // Check if any mutations affect the elements we're monitoring
      const shouldCheck = mutations.some((mutation) => {
        if (mutation.type === "childList") {
          // Check if added/removed nodes contain our target elements
          const nodes = [...mutation.addedNodes, ...mutation.removedNodes];
          return nodes.some((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              return this.containsRelevantElement(node);
            }
            return false;
          });
        }
        if (mutation.type === "attributes") {
          // Check if attribute changes are on elements we care about
          return this.isRelevantElement(mutation.target);
        }
        return false;
      });

      if (shouldCheck) {
        this.checkStatus();
      }
    });

    // Start observing
    this.observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["disabled", "class", "aria-disabled"],
    });
  }

  containsRelevantElement(element) {
    // Check if element or its descendants contain send/stop buttons
    const selectors = [
      '[data-testid="send-button"]',
      '[data-testid="stop-button"]',
      'button[aria-label*="Send"]',
      'button[aria-label*="Stop"]',
      'button:has(svg[data-icon="paper-plane"])',
      'button:has(svg[data-icon="stop"])',
      ".btn-primary:has(svg)",
      'button:has([data-icon="paper-plane"])',
      'button:has([data-icon="stop"])',
    ];

    return selectors.some((selector) => {
      try {
        return element.querySelector && element.querySelector(selector);
      } catch (e) {
        return false;
      }
    });
  }

  isRelevantElement(element) {
    // Check if the element itself is a send/stop button
    const selectors = [
      '[data-testid="send-button"]',
      '[data-testid="stop-button"]',
      'button[aria-label*="Send"]',
      'button[aria-label*="Stop"]',
    ];

    return selectors.some((selector) => {
      try {
        return element.matches && element.matches(selector);
      } catch (e) {
        return false;
      }
    });
  }

  checkStatus() {
    // Check if extension context is still valid
    if (!chrome.runtime || !chrome.runtime.id) {
      this.destroy();
      return;
    }

    const newStatus = this.detectStatus();

    // Detect title/baseTitle changes independently of status changes
    let titleChanged = false;
    try {
      const currentCleanTitle = this.getCleanTitle();
      if (
        currentCleanTitle &&
        currentCleanTitle.trim() !== "" &&
        currentCleanTitle !== this.baseTitle
      ) {
        this.baseTitle = currentCleanTitle;
        titleChanged = true;
      }
    } catch (e) {
      // ignore title read errors
    }

    const statusChanged = newStatus !== this.currentStatus;

    if (statusChanged || titleChanged) {
      const now = Date.now();
      const timeSinceLastChange = now - this.lastStatusChange;

      // Rate-limit only status changes; allow immediate title updates
      const canNotifyStatusChange =
        this.currentStatus === null ||
        newStatus === "processing" ||
        timeSinceLastChange >= this.statusChangeDelay;

      if ((statusChanged && canNotifyStatusChange) || titleChanged) {
        const oldStatus = this.currentStatus;
        if (statusChanged) {
          this.currentStatus = newStatus;
          this.lastStatusChange = now;
        }
        // Always notify when either status or title changed
        this.notifyStatusChange(newStatus, oldStatus);
      }
    }
  }

  detectStatus() {
    // Look for the specific streaming stop button
    const streamingButton = this.findStreamingStopButton();
    if (streamingButton) {
      return "processing";
    }

    // Default to ready/idle
    return "ready";
  }

  findStreamingStopButton() {
    // Look for the specific streaming stop button
    // <button id="composer-submit-button" aria-label="Stop streaming" data-testid="stop-button"
    const streamingButton = document.querySelector(
      '#composer-submit-button[aria-label="Stop streaming"][data-testid="stop-button"]'
    );

    if (streamingButton && streamingButton.offsetParent !== null) {
      return streamingButton;
    }

    // Fallback selectors in case the structure changes slightly
    const fallbackSelectors = [
      'button[aria-label="Stop streaming"]',
      'button[data-testid="stop-button"][aria-label*="Stop"]',
      '#composer-submit-button[data-testid="stop-button"]',
    ];

    for (const selector of fallbackSelectors) {
      try {
        const element = document.querySelector(selector);
        if (element && element.offsetParent !== null) {
          // visible
          return element;
        }
      } catch (e) {
        continue;
      }
    }
    return null;
  }

  getCleanTitle() {
    // Remove existing status emojis and clean up the title
    return document.title.replace(/^(🔴|🟢)\s+/, "").trim();
  }

  updateTitle(status) {
    try {
      // Update the base title if it has changed (e.g., new conversation started)
      const currentCleanTitle = this.getCleanTitle();
      if (
        !this.baseTitle ||
        (currentCleanTitle && currentCleanTitle !== this.baseTitle)
      ) {
        this.baseTitle = currentCleanTitle || "ChatGPT";
      }

      // Ensure we have a valid base title
      if (!this.baseTitle || this.baseTitle.trim() === "") {
        this.baseTitle = "ChatGPT";
      }

      // Apply status emoji to title
      const statusEmoji = status === "processing" ? "🔴" : "🟢";
      const newTitle = `${statusEmoji} ${this.baseTitle}`;

      // Only update if title actually changed to avoid unnecessary DOM updates
      if (document.title !== newTitle) {
        document.title = newTitle;
      }
    } catch (error) {
    }
  }

  async notifyStatusChange(status, oldStatus) {
    // Update title directly in content script
    this.updateTitle(status);

    // Notify background and await chime command
    try {
      const response = await chrome.runtime.sendMessage({ 
        type: "STATUS_UPDATE", 
        status: status, 
        oldStatus: oldStatus,
        tabId: window.location.href
      });
      
      // Play the chime based on background's decision and user settings
      if (response && response.chimeCommand && this.settings.getChimesEnabled()) {
        
        switch (response.chimeCommand) {
          case "PLAY_PROCESSING_CHIME":
            this.playLowCChime();
            break;
          case "PLAY_TAB_READY_CHIME":
            this.playGChime();
            break;
          case "PLAY_WINDOW_READY_CHIME":
            this.playHighCChime();
            break;
        }
      } else if (response && response.chimeCommand && !this.settings.getChimesEnabled()) {
      }
    } catch (e) {
    }
  }

  async playLowCChime() {
    await this.chimePlayer.playLowCChime();
  }

  async playGChime() {
    await this.chimePlayer.playGChime();
  }

  async playHighCChime() {
    await this.chimePlayer.playHighCChime();
  }

  destroy() {
    if (this.observer) {
      this.observer.disconnect();
    }
  }
}

// Initialize monitor (avoid double-injection)
if (!window.__CHATGPT_MONITOR_ACTIVE__) {
  window.__CHATGPT_MONITOR_ACTIVE__ = true;
  const monitor = new ChatGPTMonitor();
  
  // Cleanup on page unload
  window.addEventListener("beforeunload", () => {
    monitor.destroy();
  });
} else {
}
